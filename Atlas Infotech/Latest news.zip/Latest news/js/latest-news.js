$(document).ready(function(){

    //  Owl Carousel Slider Start 
   
    $('.owl-latest-news').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        items:1,
        nav: false,
       
    })
})