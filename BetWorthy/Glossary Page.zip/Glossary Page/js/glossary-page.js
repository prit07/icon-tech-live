$(document).ready(function(){


    // 

    $('.glossary-table .glossary-menu a').click(function(){
        $('.glossary-menu a').removeClass("active");
        $(this).addClass("active");
    });
    
  });