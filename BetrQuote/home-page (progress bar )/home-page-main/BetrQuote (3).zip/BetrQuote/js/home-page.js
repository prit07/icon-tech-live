jQuery(document).ready(function () {
    var widget = $(".fieldset-wapper");
    var btnnext = $(".btn-next");

    function setProgress(currstep) {
        var percent = parseFloat(100 / widget.length) * currstep;
        percent = percent.toFixed();
        $(".progress-bg>div").css("width", percent + "%");
        $(".progress-text").text(percent + "%");
    }

    var current = 1;
    setProgress(current);
    widget.not(':eq(0)').removeClass('fieldset-active');

    // Validation function
    function validateCurrentStep() {
        var isValid = true;
        
        // Validate ZIP Code
        if (current === 1) {
            var zipCode = $('input[placeholder="ZIP Code"]').val().trim();
            var zipCodePattern = /^\d{6}$/; // 6-digit ZIP code pattern
            if (!zipCode || !zipCodePattern.test(zipCode)) {
                alert('Please enter a valid 6-digit ZIP code.');
                isValid = false;
            }
        }
        
        // Validate Address
        if (current === 3) {
            var address = $('input[placeholder="type Here e.g. 123 West Main Road"]').val().trim();
            if (!address) {
                alert('Please enter your street address.');
                isValid = false;
            }
        }

        // Validate Email
        if (current === 4) {
            var email = $('input[placeholder="Email address"]').val().trim();
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Basic email pattern
            if (!email || !emailPattern.test(email)) {
                alert('Please enter a valid email address.');
                isValid = false;
            }
        }

        // Validate First Name and Last Name
        if (current === 5) {
            var firstName = $('input[placeholder="Enter first name"]').val().trim();
            var lastName = $('input[placeholder="Enter last name"]').val().trim();
            if (!firstName) {
                alert('Please enter your first name.');
                isValid = false;
            }
            if (!lastName) {
                alert('Please enter your last name.');
                isValid = false;
            }
        }

        return isValid;
    }

    btnnext.click(function () {
        $('.fieldset-progress-bar').addClass('d-flex');

        // Validate current step before moving to the next
        if (validateCurrentStep()) {
            if (current < widget.length) {
                widget.addClass('fieldset-active');
                widget.not(':eq(' + (current++) + ')').removeClass('fieldset-active');
                setProgress(current);
            }
        }
    });

    jQuery('.btn-back').click(function () {
        var cur = jQuery('.fieldset-wapper').index(jQuery('.fieldset-wapper.fieldset-active'));
        jQuery('.fieldset-wapper').removeClass('fieldset-active');
        jQuery('.fieldset-wapper').eq(cur - 1).addClass('fieldset-active');
        setProgress(current - 1);
    });

    jQuery('.btn-back-h').click(function () {
        $('.fieldset-progress-bar').removeClass('d-flex').addClass('d-none');
    });

    // Slider JS start
    jQuery("#reviews-slider").owlCarousel({
        autoplay: true,
        margin: 56,
        loop: true,
        responsiveClass: true,
        autoHeight: true,
        stagePadding: 45,
        dots: true,
        autoplayTimeout: 7000,
        smartSpeed: 800,
        nav: true,
        navText: [
            '<svg class="splide__arrowImg" width="32" height="32" viewBox="0 0 32 32" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M24.7598 16.8496L12.3854 4.47524L10.2641 6.59656L20.5171 16.8496L10.2641 27.1027L12.3854 29.224L24.7598 16.8496Z" fill="#4E46E4"></path></svg>',
            '<svg class="splide__arrowImg" width="32" height="32" viewBox="0 0 32 32" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M24.7598 16.8496L12.3854 4.47524L10.2641 6.59656L20.5171 16.8496L10.2641 27.1027L12.3854 29.224L24.7598 16.8496Z" fill="#4E46E4"></path></svg>'
        ],
        responsive: {
            0: {
                items: 1,
                margin: 0,
                stagePadding: 0,
            },
            600: {
                items: 2,
                margin: 30,
                stagePadding: 20,
            },
            1024: {
                margin: 40,
                items: 3,
                stagePadding: 30,
            },
            1366: {
                items: 3
            }
        }
    });
});
t