$(document).ready(function(){
    $('.owl-banner-slider').owlCarousel({
        loop:true,
        margin:10,
        nav:false,
        items:1,
      
    })
})