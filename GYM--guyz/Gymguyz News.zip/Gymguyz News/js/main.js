$(document).ready(function(){
    $('.owl-gymguyz-news').owlCarousel({
        loop:true,
        margin:0,
        nav:false,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1100:{
                items:3
            }
        }
    })
})



