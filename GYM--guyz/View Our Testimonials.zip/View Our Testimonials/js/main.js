$(document).ready(function(){
    $('.owl-our-testimonials').owlCarousel({
        loop:true,
        margin:10,
        nav:false,
        items:1
    })
})