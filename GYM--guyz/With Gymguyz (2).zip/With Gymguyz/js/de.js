
$(document).ready(function () {
    var mainCarousel = $('#main-carousel');
    var thumbCarousel = $('#thumb-carousel');

    mainCarousel.owlCarousel({
        items: 3,
        loop: true,
        nav: false,
        dots: false,
        margin: 40,
        
    });

    thumbCarousel.owlCarousel({
        items: 4,
        loop: true,
        nav: true,
        dots: false,
        margin: 10,
        navText: [
            '<span class="arrow-h-left"><img src="img/left.png"></span>',
            '<span class="arrow-h-right"><img src="img/right.png"></span>'
        ]
    });


    // Click event for main carousel navigation 
    mainCarousel.on('click', '.owl-next', function () {
        thumbCarousel.trigger('next.owl.carousel');
    });
    mainCarousel.on('click', '.owl-prev', function () {
        thumbCarousel.trigger('prev.owl.carousel');
    });

    // Click event for thumbnail carousel navigation
    thumbCarousel.on('click', '.owl-next', function () {
        mainCarousel.trigger('next.owl.carousel');
    });
    thumbCarousel.on('click', '.owl-prev', function () {
        mainCarousel.trigger('prev.owl.carousel');
    });

    // Click event for main carousel left side navigation     
    mainCarousel.on('click', '.owl-stage', function (e) {
        if ($(e.target).closest('.owl-item').index() === 0) {
            mainCarousel.trigger('prev.owl.carousel');
        }
    });
    mainCarousel.on('changed.owl.carousel', function(event) {
        $('.main-carousel-items-first-text').removeClass('main-carousel-bg');
        var currentIndex = event.item.index;
        var currentItem = mainCarousel.find('.owl-item').eq(currentIndex).find('.main-carousel-items-first-text');
        currentItem.addClass('main-carousel-bg');
    });
    
});


//   owl-item  find  eq(0) addClass cureent and remove ;