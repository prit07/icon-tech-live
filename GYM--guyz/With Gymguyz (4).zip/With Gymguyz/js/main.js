$(document).ready(function () {
    var mainCarousel = $('#main-carousel');
    var thumbCarousel = $('#thumb-carousel');

    mainCarousel.owlCarousel({
        loop: true,
        nav: false,
        dots: false,
        merge:true,
        margin: 40,
        responsive: {
            0: {
                items: 1 
            },
            737: {
                items: 2 
            },
            992: {
                items: 3 ,
                mergeFit:false
            }
        }
    });

    thumbCarousel.owlCarousel({
        items: 4,
        autoWidth: true,
        loop: true,
        nav: true,
        dots: false,
        margin: 10,
        navText: [
            '<span class="arrow-h-left"><img src="img/left.png"></span>',
            '<span class="arrow-h-right"><img src="img/right.png"></span>'
        ]
    });

    // Synchronize main carousel with thumbnail carousel
    mainCarousel.on('click', '.owl-next', function () {
        thumbCarousel.trigger('next.owl.carousel');
    });
    mainCarousel.on('click', '.owl-prev', function () {
        thumbCarousel.trigger('prev.owl.carousel');
    });

    thumbCarousel.on('click', '.owl-next', function () {
        mainCarousel.trigger('next.owl.carousel');
    });
    thumbCarousel.on('click', '.owl-prev', function () {
        mainCarousel.trigger('prev.owl.carousel');
    });

    // Add class to the current active item for styling purposes
    mainCarousel.find(".owl-item").eq(3).addClass("demo");
    mainCarousel.on('changed.owl.carousel', function (event) {
        mainCarousel.find(".demo").removeClass("demo");
        mainCarousel.find(".owl-item").eq(event.item.index).addClass("demo");
    
        $(".main-carousel-items-first-text").removeClass("main-carousel-bg");
        $(".demo").find(".main-carousel-items-first-text").addClass("main-carousel-bg");
    });


});


