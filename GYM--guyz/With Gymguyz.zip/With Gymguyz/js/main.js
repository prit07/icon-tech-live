// $(document).ready(function () {
//     var mainCarousel = $('#main-carousel');
//     var thumbCarousel = $('#thumb-carousel');

//     mainCarousel.owlCarousel({
//         items: 3,
//         loop: true,
//         nav: false,
//         dots: false,
//         margin:30,
       

//     });

//     thumbCarousel.owlCarousel({
//         items: 4,
//         loop: true,
//         nav: true,
//         dots: true,
//         margin: 10,
//         responsive: {
//             0: {
//                 items: 3
//             },
//             600: {
//                 items: 3
//             }
//         }
//     });


//     // Click event for main carousel navigation
//     mainCarousel.on('click', '.owl-next', function () {
//         thumbCarousel.trigger('next.owl.carousel');
//     });
//     mainCarousel.on('click', '.owl-prev', function () {
//         thumbCarousel.trigger('prev.owl.carousel');
//     });

//     // Click event for thumbnail carousel navigation
//     thumbCarousel.on('click', '.owl-next', function () {
//         mainCarousel.trigger('next.owl.carousel');
//     });
//     thumbCarousel.on('click', '.owl-prev', function () {
//         mainCarousel.trigger('prev.owl.carousel');
//     });


//     // // Click event for thumbnail carousel navigation
//     // thumbCarousel.on('click', '.owl-thumb-item', function () {
//     //     var index = $(this).data('slide-index');
//     //     mainCarousel.trigger('to.owl.carousel', [index, 300, true]);
//     // });
//     thumbCarousel.on('click', '.owl-thumb-item', function () {
//         var index = $(this).data('slide-index');
//         mainCarousel.trigger('to.owl.carousel', [index, 0, true]); 
//     });

//     // Click event for main carousel navigation
//     // mainCarousel.on('changed.owl.carousel', function (event) {
//     //     if (!event.namespace || event.property.name !== 'position') return;
//     //     var index = event.relatedTarget.relative(event.property.value);
//     //     thumbCarousel.trigger('to.owl.carousel', [index, 300, true]);
//     // });
// });
$(document).ready(function () {
    var mainCarousel = $('#main-carousel');
    var thumbCarousel = $('#thumb-carousel');

    mainCarousel.owlCarousel({
        autoWidth:true,
        items: 3,
        loop: true,
        nav: false,
        dots: false,
        margin: 40,
        
    });

    thumbCarousel.owlCarousel({
        autoWidth:true,
        items: 4,
        loop: true,
        nav: true,
        dots: false,
        margin: 10,
        navText: [
            '<span class="arrow-h-left"><img src="img/left.png"></span>',
            '<span class="arrow-h-right"><img src="img/right.png"></span>'
          ]
    });


    // Click event for main carousel navigation 
    mainCarousel.on('click', '.owl-next', function () {
        thumbCarousel.trigger('next.owl.carousel');
    });
    mainCarousel.on('click', '.owl-prev', function () {
        thumbCarousel.trigger('prev.owl.carousel');
    });

    // Click event for thumbnail carousel navigation
    thumbCarousel.on('click', '.owl-next', function () {
        mainCarousel.trigger('next.owl.carousel');
    });
    thumbCarousel.on('click', '.owl-prev', function () {
        mainCarousel.trigger('prev.owl.carousel');
    });


    // Click event for thumbnail carousel navigation
    // thumbCarousel.on('click', '.owl-thumb-item', function () {
    //     var index = $(this).data('slide-index');
    //     mainCarousel.trigger('to.owl.carousel', [index, 0, true]); 
    // });

});


