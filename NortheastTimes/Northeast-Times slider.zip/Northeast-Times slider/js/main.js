$(document).ready(function () {
    var owl = $('.owl-northeast-time').owlCarousel({
        loop: false, // Disable looping to properly hide arrows at boundaries
        margin: 10,
        nav: true,
        items: 1,
        dots: false,
        navText: [
            '<span><img src="img/right-slider-arrow.png"></span>',
            '<span><img src="img/left-slider-arrow.png"></span>'
        ],
    });

    owl.on('changed.owl.carousel', function (event) {
        var totalItems = event.item.count;
        var currentIndex = event.item.index; 

        // Show/hide arrows based on the current index
        $('.owl-prev').toggle(currentIndex !== 0); 
        $('.owl-next').toggle(currentIndex !== totalItems - 1);
    });

    // Trigger the check on initialization
    owl.trigger('changed.owl.carousel');
});
