jQuery(document).ready(function(){

	// pbd thubline img
	const $thumbnails = $('.pbd-thublin-img img');
	const $mainImgDiv = $('.pbd-main-img');

	function updateMainImage(src, alt) {
		$mainImgDiv.empty();
		const $newImg = $('<img>').attr('src', src).attr('alt', alt);
		$mainImgDiv.append($newImg);
	}

	$thumbnails.on('click', function() {
		const src = $(this).attr('src');
		const alt = $(this).attr('alt');

		updateMainImage(src, alt);
	});

	if ($thumbnails.length > 0) {
		const $firstThumbnail = $thumbnails.first();
		updateMainImage($firstThumbnail.attr('src'), $firstThumbnail.attr('alt'));
	}


	// Dropdown
	$('.pbd-escoge-dropdown').click(function () {
		$(this).attr('tabindex', 1).focus();
		$(this).toggleClass('active');
		$(this).find('.pbd-dropdown-menu').slideToggle(300);
	});
	$('.dropdown').focusout(function () {
		$(this).removeClass('active');
		$(this).find('.pbd-dropdown-menu').slideUp(300);
	});
	$('.pbd-escoge-dropdown  .pbd-dropdown-menu li').click(function () {
		$(this).parents('.pbd-escoge-dropdown').find('h4').text($(this).text());
		$(this).parents('.pbd-escoge-dropdown').find('input').attr('value', $(this).text());
	});
	


// button switch  pbd-quiero-progress-wapper
	const pbdToggleSwitch = document.querySelector('.pbd-quiero-theme-switch input[type="checkbox"]');
	const pbdCurrentTheme = localStorage.getItem('theme');
	jQuery('#pbd-quiero-switch-text').html(pbdCurrentTheme)

	if (pbdCurrentTheme) {
		document.documentElement.setAttribute('data-theme', pbdCurrentTheme);
		if (pbdCurrentTheme === 'Si') {
			pbdToggleSwitch.checked = true;
			jQuery('.pbd-quiero-progress-wapper').css('display', 'block');
		} else {
			jQuery('.pbd-quiero-progress-wapper').css('display', 'none');
		}
	}
	function switchTheme(e) {
		if (e.target.checked) {
			document.documentElement.setAttribute('data-theme', 'Si');
			localStorage.setItem('theme', 'Si');

			jQuery('#pbd-quiero-switch-text').html(localStorage.getItem("theme"));
			jQuery('.pbd-quiero-progress-wapper').css('display', 'block');
		}
		else {
			document.documentElement.setAttribute('data-theme', 'No');
			localStorage.setItem('theme', 'No');
			jQuery('.pbd-quiero-progress-wapper').css('display', 'none');
			jQuery('#pbd-quiero-switch-text').html(localStorage.getItem("theme"));;
		}
	}
	pbdToggleSwitch.addEventListener('change', switchTheme, false);



// button switch pbd-salsa-progress-wapper
	const pbdSalsaToggleSwitch = document.querySelector('.pbd-salsa-theme-switch input[type="checkbox"]');
    const pbdSalsaCurrentTheme = localStorage.getItem('salsaTheme');

    console.log('pbdSalsaToggleSwitch:', pbdSalsaToggleSwitch); // Check if pbdSalsaToggleSwitch is correctly selected
    console.log('pbdSalsaCurrentTheme:', pbdSalsaCurrentTheme); // Check the current theme value from localStorage

    if (pbdSalsaCurrentTheme) {
        document.documentElement.setAttribute('data-salsa-theme', pbdSalsaCurrentTheme);
        if (pbdSalsaCurrentTheme === 'Si') {
            pbdSalsaToggleSwitch.checked = true;
            jQuery('.pbd-salsa-progress-wapper').css('display', 'block');
        } else {
            jQuery('.pbd-salsa-progress-wapper').css('display', 'none');
        }
        jQuery('#pbd-salsa-switch-text').html(pbdSalsaCurrentTheme);
    }

    function switchSalsaTheme(e) {
        if (e.target.checked) {
            document.documentElement.setAttribute('data-salsa-theme', 'Si');
            localStorage.setItem('salsaTheme', 'Si');
            jQuery('.pbd-salsa-progress-wapper').css('display', 'block');
            jQuery('#pbd-salsa-switch-text').html(localStorage.getItem("salsaTheme"));
        } else {
            document.documentElement.setAttribute('data-salsa-theme', 'No');
            localStorage.setItem('salsaTheme', 'No');
            jQuery('.pbd-salsa-progress-wapper').css('display', 'none');
            jQuery('#pbd-salsa-switch-text').html(localStorage.getItem("salsaTheme"));
        }
    }

    if (pbdSalsaToggleSwitch) { 
        pbdSalsaToggleSwitch.addEventListener('change', switchSalsaTheme, false);
    } else {
        console.log('pbdSalsaToggleSwitch is null or undefined.'); 
    }




	// pbd wapper m slider

	var owl = jQuery('.pbd-wapper-m-slider').owlCarousel({
		margin:32,
		nav:false,
		autoplay:false,
		dots:false, 
		loop: true,
		center:true,
		responsive:{
			0:{ 
				items:2.1,
				
			},
		
		}
	});	

})