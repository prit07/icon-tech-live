jQuery(document).ready(function(){

	// pbd thubline img
	const $thumbnails = $('.pbd-thublin-img img');
	const $mainImgDiv = $('.pbd-main-img');

	function updateMainImage(src, alt) {
		$mainImgDiv.empty();
		const $newImg = $('<img>').attr('src', src).attr('alt', alt);
		$mainImgDiv.append($newImg);
	}

	$thumbnails.on('click', function() {
		const src = $(this).attr('src');
		const alt = $(this).attr('alt');

		updateMainImage(src, alt);
	});

	if ($thumbnails.length > 0) {
		const $firstThumbnail = $thumbnails.first();
		updateMainImage($firstThumbnail.attr('src'), $firstThumbnail.attr('alt'));
	}


	// Dropdown

	$('.pbd-escoge-dropdown').click(function () {
		$(this).attr('tabindex', 1).focus();
		$(this).toggleClass('active');
		$(this).find('.pbd-dropdown-menu').slideToggle(300);
	});
	$('.dropdown').focusout(function () {
		$(this).removeClass('active');
		$(this).find('.pbd-dropdown-menu').slideUp(300);
	});
	$('.pbd-escoge-dropdown  .pbd-dropdown-menu li').click(function () {
		$(this).parents('.pbd-escoge-dropdown').find('h4').text($(this).text());
		$(this).parents('.pbd-escoge-dropdown').find('input').attr('value', $(this).text());
	});
	
})