jQuery(document).ready(function(){

    const $productThumbnails = $('.product-details-thublin-img img');
	const $productmainImgDiv = $('.product-details-main-img');

	function updateMainImage(src, alt) {
		$productmainImgDiv.empty();
		const $newImg = $('<img>').attr('src', src).attr('alt', alt);
		$productmainImgDiv.append($newImg);
	}

	$productThumbnails.on('click', function() {
		const src = $(this).attr('src');
		const alt = $(this).attr('alt');

		updateMainImage(src, alt);
	});

	if ($productThumbnails.length > 0) {
		const $firstThumbnail = $productThumbnails.first();
		updateMainImage($firstThumbnail.attr('src'), $firstThumbnail.attr('alt'));
	}


	// Quantity js start
	var productButtonPlus  = $(".product-details-sidebar-qty-btn-plus");
	var productButtonMinus = $(".product-details-sidebar-qty-btn-minus");
	var incrementPlus = productButtonPlus.click(function() {
		var $n = $(this).parent(".product-details-sidebar-qty-container").find(".product-details-sidebar-input-qty");
		$n.val(Number($n.val())+1 );
	});
	var incrementMinus = productButtonMinus.click(function() {
		var $n = $(this).parent(".product-details-sidebar-qty-container").find(".product-details-sidebar-input-qty");
		var amount = Number($n.val());
		if (amount > 0) {
			$n.val(amount-1);
		}
	});

	// faq
	jQuery(".product-details-faq-item .product-details-faq-menu").on("click", function () {
		if (jQuery(this).parent().hasClass("active")) {
		  jQuery(this).next().slideUp();
		  jQuery(this).parent().removeClass("active");
		}
		else {
		  jQuery(".product-details-faq-content").slideUp();
		  jQuery(".product-details-faq-item").removeClass("active");
		  jQuery(this).parent().addClass("active");
		  jQuery(this).next().slideDown();
		}
	  });



	//   mobile view slider
	
	var owl = jQuery('.pbd-wapper-m-slider').owlCarousel({
		margin:32,
		nav:false,
		autoplay:false,
		dots:false, 
		loop: true,
		center:true,
		responsive:{
			0:{ 
				items:2.1,
				
			},
		
		}
	});	

})