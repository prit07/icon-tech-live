jQuery(document).ready(function(){

	/* sidebar Quantity js start */
	var buttonPlus  = $(".product-list-sidebar-qty-btn-plus");
	var buttonMinus = $(".product-list-sidebar-qty-btn-minus");
	var incrementPlus = buttonPlus.click(function() {
		var $n = $(this).parent(".product-list-sidebar-qty-container").find(".product-list-sidebar-input-qty");
		$n.val(Number($n.val())+1 );
	});
	var incrementMinus = buttonMinus.click(function() {
		var $n = $(this).parent(".product-list-sidebar-qty-container").find(".product-list-sidebar-input-qty");
		var amount = Number($n.val());
		if (amount > 0) {
			$n.val(amount-1);
		}
	});
	/* sidebar Quantity js end */

	/* sidebar progress bar js start */
	var totalQuestions = 14;
	var current_q =  jQuery('.product-list-sidebar-p-card').length;
	jQuery('.product-list-sidebar-progress-1').css("width", Math.round(100 * current_q / totalQuestions) + "%");
	jQuery('#product-list-sidebar-selected-product').html(current_q)
	/* sidebar progress bar js end */

	/* sidebar toggle switch js start */
	const toggle_Switch = document.querySelector('.product-list-switch input[type="checkbox"]');
	const current_Theme = localStorage.getItem('data-product-list');
	jQuery('#product-list-s-switch-text').html(current_Theme)

	if (current_Theme) {
		document.documentElement.setAttribute('data-product-list', current_Theme);
		if (current_Theme === 'Si') {
			toggle_Switch.checked = true;
		}
	}
	function switch_Theme(e) {
		if (e.target.checked) {
			document.documentElement.setAttribute('data-product-list', 'Si');
			localStorage.setItem('data-product-list', 'Si');
			jQuery('#product-list-s-switch-text').html(localStorage.getItem("data-product-list"));
		}
		else {        
			document.documentElement.setAttribute('data-product-list', 'No');
			localStorage.setItem('data-product-list', 'No');
			jQuery('#product-list-s-switch-text').html(localStorage.getItem("data-product-list"));
		}    
	}
	toggle_Switch.addEventListener('change', switch_Theme, false);
	/* sidebar toggle switch js end */

})