jQuery(document).ready(function(){
    var owl = jQuery('.owl-related-product-slider').owlCarousel({
        margin:32,
		nav:false,
		autoplay:false,
		dots:false, 
		loop: true,
	
        responsive:{
            0:{ 
                items:2,
                center:false,
                stagePadding: 50,
                margin:10,
            },
            450: {
                items:3.9,
                center:true,
            },
            991: {
                items:4.1,
                center:true,
            },
        
            1100: {
                items:4, 
                stagePadding: 190,
            },
        }
    }); 

    
});
