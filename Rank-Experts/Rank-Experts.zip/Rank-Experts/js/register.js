$(document).ready(function(){
	// mobile code
	$("#mobile_code").intlTelInput({
		initialCountry: "in",
		separateDialCode: false,
	});
})