$(document).ready(function(){
    $('.owl-home-page').owlCarousel({
          items:1,
          nav: true,
          loop:true,
          navText: ['<span class="arrow-h-left"><i class="fas fa-chevron-left"></i></span>','<span class="arrow-h-right"><i class="fas fa-chevron-right"></i></span>'],
          autoplay: false,
          dots: true,
          dotsData: true,
      });
  });