$(document).ready(function() {
    $(".hudsonreporter-calendar-day h5").click(function() {
        // Remove the active class from all <h5> elements
        $(".hudsonreporter-calendar-day h5").removeClass("active");
        
        // Add the active class to the clicked <h5> element
        $(this).addClass("active");
    });
});