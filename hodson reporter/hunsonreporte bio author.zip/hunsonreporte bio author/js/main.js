// $(document).ready(function() {
//     jQuery(".itpl-product-color-attribute").slice(0, 3).show();
//     jQuery("body").on('click touchstart', '#seeMore', function (e) {
//         e.preventDefault();
//         jQuery(".itpl-product-color-attribute:hidden").slice(0, 3).slideDown();
//         if (jQuery(".itpl-product-color-attribute:hidden").length == 0) {
//             jQuery("#seeMore").css('visibility', 'hidden');
//         }
//         jQuery('html,body').animate({
//             scrollTop: $(this).offset().top
//         }, 1000);
//     });

// }) 