$(document).ready(function () {
    $(".latest-top-right-img").slice(0, 6).show();
     $("#seeMore").on('click', function (e) {
         e.preventDefault();
         $(".latest-top-right-img:hidden").slice(0, 3).slideDown();
         if ($(".latest-top-right-img:hidden").length == 0) {
             $("#seeMore").remove();
         }
     });

})