$(document).ready(function(){

    //  Owl Carousel Slider Start 
   
    $('.owl-home-page-slider').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        items:1,
        dots:false,
        navText: [
			'<span><i class="fas fa-chevron-up right"></i></span>',
			'<span><i class="fas fa-chevron-down left"></i></span>'
			],
        
       
    })
})