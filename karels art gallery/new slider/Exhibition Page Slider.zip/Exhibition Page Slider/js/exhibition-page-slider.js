$(document).ready(function(){

    //  Owl Carousel Slider Start 
   
    $('.owl-exhibition-page-slider').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        items:1,
        dots:false,
        navText: [
			'<span><i class="fas fa-chevron-left"></i></span>',
			'<span><i class="fas fa-chevron-right"></i></span>'
			],
        
       
    })
})