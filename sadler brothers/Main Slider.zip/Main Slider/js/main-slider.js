$(document).ready(function(){
    $('.owl-main-slider').owlCarousel({
        loop:true,
        margin:0,
        nav:false,
        items:1,
    })
})