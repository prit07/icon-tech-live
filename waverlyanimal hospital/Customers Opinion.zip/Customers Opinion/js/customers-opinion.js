$(document).ready(function(){
    $('.owl-customers-opinion').owlCarousel({
        loop:true,
        margin:30,
        nav:false,
        items:1,
        responsive:{
            0:{
            
            },
            600:{
              
            },
            1000:{
                margin:0,
            }
        }
    })
})